SLEEP Paper — LaTeX Source
==========================

Paper: "Recognition Without Recall: Empirical Limits of
        Biologically-Inspired Memory Consolidation in Transformers"

Authors: Aditya Tripathi (adityatripathi1503@gmail.com)
         Dr. Rachit Garg (S P Jain School of Global Management)


Files in this archive
---------------------
  main.tex                        Master document; \input's each section.
  references.bib                  BibTeX bibliography (plainnat style).
  sections/01_abstract_intro.tex  Abstract + Introduction (Contributions C1-C6).
  sections/02_background_method.tex
                                  Related Work + Background +
                                  Problem Statement + The SLEEP Architecture.
  sections/03_experimental_setup.tex
                                  Experimental Setup.
  sections/04_results.tex         Results (six subsections).
  sections/05_related_discussion_conclusion.tex
                                  Discussion + Conclusion and Future Scope.
  sections/06_appendix.tex        Annexure (A: amendments, B: hyperparameters,
                                  C: implementation details, D: multi-cycle config).
  figures/figure_pareto_frontier.pdf
  figures/figure_substrate_comparison.pdf
  figures/figure_architecture.pdf
  figures/figure_multi_cycle.pdf  Four PDF figures included via \includegraphics.
  figures/generate_figures.py     Matplotlib script that regenerates the
                                  figures from raw numbers (optional;
                                  needs numpy + matplotlib).


How to compile (PDF output)
---------------------------

Option 1 - Local LaTeX (MiKTeX on Windows, TeX Live on macOS/Linux):

    pdflatex main
    bibtex   main
    pdflatex main
    pdflatex main

The three pdflatex passes are needed for cross-references and the
bibliography. The output is main.pdf.

Option 2 - Overleaf (no install required):

    1. Go to https://www.overleaf.com
    2. New Project -> Upload Project -> select this zip.
    3. Set the main document to "main.tex" if Overleaf doesn't auto-detect.
    4. Compiler: pdfLaTeX (the default).
    5. Click Recompile.


Required LaTeX packages
-----------------------
All standard, available in any recent TeX distribution:
  inputenc, fontenc, amsmath, amssymb, amsfonts, graphicx, booktabs,
  hyperref, algorithm, algorithmic, xcolor, subcaption, multirow,
  enumitem, natbib, geometry.


Editing notes
-------------
- Section files are \input'd from main.tex in document order. Edit each
  in place; do not rename without updating main.tex.
- The Annexure (06_appendix.tex) uses \renewcommand{\thesection} to make
  section headings read "Annexure A", "Annexure B", etc. Leave that as is.
- Citation style is author-year via natbib + plainnat. Use \citep{key}
  for parenthetical and \citet{key} for textual citations.
- Figures regenerate by running:  python figures/generate_figures.py
  This produces both .pdf (for LaTeX) and .png (used for the .docx
  conversion). LaTeX only needs the .pdf versions.


Contact
-------
Aditya Tripathi - adityatripathi1503@gmail.com
